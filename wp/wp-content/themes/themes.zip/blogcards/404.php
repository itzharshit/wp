<?php get_header(); ?>

<?php get_template_part('inc/page-title'); ?>

<?php get_footer(); ?>