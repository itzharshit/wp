;(function($) {

 	"use strict";

 	wp.customize.controlConstructor['bloghash-alignment'] = wp.customize.Control.extend({

		ready: function() {

			'use strict';

			var control = this;
		},

	});

})(jQuery);